from itertools import zip_longest  # noqa: F401
from collections.abc import Iterable  # noqa: F401

to_unicode = str
basestring = (str, bytes)
